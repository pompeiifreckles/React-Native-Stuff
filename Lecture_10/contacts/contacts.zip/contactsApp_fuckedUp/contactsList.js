import React from 'react'
import {SectionList,Text, View} from 'react-native'
import PropTypes from 'prop-types'

import Row from './Row'

const ContactsList = ({contacts}) => {

    const contactsByLetter = contacts.reduce((obj, contact) => {
        const firstLetter = contact.name[0].toUpperCase()

        return {
            ...obj,
            [firstLetter]: [...(obj[firstLetter] || []), contact]
        }
    }, {})

    const sections = Object.keys(contactsByLetter).sort().map(letter => ({
        title: letter,
        data: contactsByLetter[letter],
        })
    )

    return(
        <SectionList 
            sections={sections}
            renderItem={({item}) => <Row contact={item}/>}
            renderSectionHeader={renderSectionHeader}
        />
    )
}

ContactsList.propTypes = {
    contacts: PropTypes.array,
}

const renderSectionHeader = ({section}) => (
    <View style={{paddingTop: 10, paddingBottom: 10}}>
        <View style={{flex: 1, backgroundColor: '#ebebeb'}}>
            <Text style={{paddingLeft: 20, fontSize: 20, color: '#62a7d1'}}>{section.title}</Text>
        </View>
    </View>
)

export default ContactsList