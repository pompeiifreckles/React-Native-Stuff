const NUM_CONTACTS = 1
const ip_address = '192.168.0.106'

export const fetchContacts = async () => {
    try {
        const response = await fetch(`https://randomuser.me/api/?results=${NUM_CONTACTS}&nat=us`)
        const contacts = await response.json()
        return contacts.results.map(processContacts)
    } catch(e) {
        console.warn(e)
    }
}

const processContacts = (contact) => ({
    name: `${contact.name.first} ${contact.name.last}`,
    phone: `${contact.phone}`,
})

export const login = async (username, password) => {
    const response = await fetch(`http://${ip_address}:8000/`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({username, password})
    })

    if(response.ok) {
        const {token} = await response.json()
        return token
    }

    const errMessage = await response.text()
    throw new Error(errMessage)
}