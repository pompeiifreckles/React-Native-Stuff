import {login} from '../api'

export const UPDATE_USER = 'UDPATE_USER'
export const UPDATE_CONTACT = 'UPDATE_CONTACT'
export const LOGIN_SENT = 'LOGIN_SENT'
export const LOGIN_SUCCESS = 'LOGIN_SUCCESS'
export const LOGIN_FAILED = 'LOGIN_FAILED'

export const updateUser = user => ({
    type: UPDATE_USER,
    payload: user,
})

export const updateContact = contact => ({
    type: UPDATE_CONTACT,
    payload: contact,
})

// async action creator

export const loginUser = (username, password) => async dispatch => {
    dispatch({type: LOGIN_SENT, error: null})

    try {
        const token = await login(username, password)   
        dispatch({type: LOGIN_SUCCESS, payload: token})
    } catch(err) {
        dispatch({type: LOGIN_FAILED, payload: err.message})
    }
}