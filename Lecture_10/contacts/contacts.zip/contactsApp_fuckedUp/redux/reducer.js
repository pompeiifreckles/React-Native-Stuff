import { combineReducers } from 'redux'
import { UPDATE_CONTACT, UPDATE_USER, LOGIN_FAILED, LOGIN_SUCCESS, LOGIN_SENT } from './actions'

import thunk from 'redux-thunk'


const merge = (prev, next) => Object.assign({}, prev, next)

const userReducer = (user = {}, action) => {
    switch(action.type) {
        case  UPDATE_USER:
            return merge(user, action.payload)
        case LOGIN_SUCCESS:
            return merge(user, {token: action.payload})
        case LOGIN_FAILED:
            return merge(user, {loginErr: action.payload})
        default:
            return user
    }
}

const contactReducer = (contacts = [], action) => {
    if(action.type === UPDATE_CONTACT)    return [...contacts, {...action.payload, key: contacts.length}]
    return contacts
}

export default reducer = combineReducers({
    user: userReducer,
    contacts: contactReducer,
})
