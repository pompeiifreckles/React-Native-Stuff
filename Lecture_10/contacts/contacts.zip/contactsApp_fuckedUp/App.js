import React from 'react';
import { NavigationContainer } from '@react-navigation/native'
import { createStackNavigator } from '@react-navigation/stack'

import ContactsListScreen from './screens/ContactsListScreen'
import AddContactScreen from './screens/AddContactScreen'
import LoginScreen from './screens/LoginScreen'

import { Provider, connect } from 'react-redux'
import { PersistGate } from 'redux-persist/integration/react'
import { store, persistor } from './redux/store'


const Stack = createStackNavigator()

export default App = () => {

  return (
    <Provider store={store}>
      <PersistGate loading={null} persistor={persistor}>
      <LaunchConnect />
      </PersistGate>
    </Provider>
  );
}

const Launch = ({token}) => {
  return (
    <>
      {
      (token !== 'thisIsARealToken') ? <LoginScreen /> : 
      <NavigationContainer>
        <Stack.Navigator>
          
          <Stack.Screen 
            name='Contacts' 
            component={ContactsListScreen} 
            options={{
              headerTitleAlign: 'center', 
            }} 
          />

          <Stack.Screen
            name='Add Contact'
            component={AddContactScreen}
            options={{
              headerTitleAlign: 'center',
            }}
          />

        </Stack.Navigator>
      </NavigationContainer>
    }
  </>
  )
}

const mapStateToProps = gState => ({
  token: gState.user.token,
})

const LaunchConnect = connect(mapStateToProps)(Launch)