import React from 'react'
import {View, Text, StyleSheet, TouchableOpacity, TextInput, KeyboardAvoidingView} from 'react-native'
import PropTypes from 'prop-types'
import {connect} from 'react-redux'

import {loginUser} from '../redux/actions'
// import {login} from '../api'

const LoginScreen = ({loginUser, err, token}) => {
    const [username, setUsername] = React.useState('')
    const [password, setPassword] = React.useState('')

    const _login = (username, password) => {
        loginUser(username, password)
    }

    return(
        <View style={styles.container}>
            <Text style={{textAlign: 'center', fontSize: 18, color: 'red'}}>{err} {token}</Text>
            <KeyboardAvoidingView>
                <TextInput 
                style={{
                    borderWidth: 1, 
                    fontSize: 18, 
                    margin: 10, 
                    marginLeft: 50, 
                    marginRight: 50, 
                    paddingLeft: 20, 
                    padding: 5,
                    borderBottomLeftRadius: 10,
                    borderBottomRightRadius:10,
                    borderTopLeftRadius: 10,
                    borderTopRightRadius: 10,
                    }} 
                value={username}
                onChangeText={setUsername}
                autoCorrect={false}
                autoCapitalize={'none'}
                placeholder='username' 
                />
                <TextInput 
                style={{
                    borderWidth: 1, 
                    fontSize: 18, 
                    margin: 10, 
                    marginLeft: 50, 
                    marginRight: 50, 
                    paddingLeft: 20,
                    padding: 5, 
                    borderBottomLeftRadius: 10,
                    borderBottomRightRadius:10,
                    borderTopLeftRadius: 10,
                    borderTopRightRadius: 10,
                    }} 
                value={password}
                onChangeText={setPassword}
                autoCorrect={false}
                autoCapitalize={'none'}
                placeholder='password' 
                />
            </KeyboardAvoidingView>

            <View style={{alignItems: 'center', paddingTop: 10}}>
            <TouchableOpacity 
            onPress={() => _login(username, password)} 
            style={{
                borderColor: '#0b8abd', 
                borderWidth: 2, 
                borderBottomLeftRadius: 25, 
                borderBottomRightRadius: 25, 
                borderTopLeftRadius: 25, 
                borderTopRightRadius: 25,
            }} >
                <Text style={{fontSize: 22, color: '#0b8abd', paddingLeft: 20, paddingRight: 20, padding: 2}}>Login</Text>
            </TouchableOpacity>
            </View>

        </View>
    )
}

LoginScreen.propTypes = {
    err: PropTypes.string,
    token: PropTypes.string,
    loginUser: PropTypes.func,
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent:'center',
    },
})

const mapStateToProps = state => ({
    err: state.user.loginErr,
    token: state.user.token,
})

export default connect(mapStateToProps, {loginUser})(LoginScreen)