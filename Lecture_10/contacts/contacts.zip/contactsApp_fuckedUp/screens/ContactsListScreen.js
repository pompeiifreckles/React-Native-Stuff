import React, { useState, useEffect, useLayoutEffect } from 'react';
import { View } from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { MaterialIcons } from '@expo/vector-icons'; 
import PropTypes from 'prop-types'

import { updateContact } from '../redux/actions'

import CONTACTS from '../contacts'
import ContactsList from '../contactsList'
import {fetchContacts} from '../api'
import { connect } from 'react-redux';

function ContactsListScreen({navigation, addContact, contacts}) {

  navigation.setOptions({
    headerRight: () => (
      <View style={{paddingRight: 20}}>
        <TouchableOpacity>
        <MaterialIcons name="add" size={20} color="#62a7d1" onPress={() => navigation.navigate('Add Contact')}/>
        </TouchableOpacity>
      </View>
    )
  })

  useLayoutEffect(() => {
    (async function () {
    const con = await fetchContacts()
    con.map(addContact)
    })()
    CONTACTS.map(addContact)
  }, [])

  return (
      <ContactsList contacts={contacts}/>
  );
}

ContactsListScreen.propTypes = {
  contacts: PropTypes.array,
}

const mapStateToProps = globalState => ({
  contacts: globalState.contacts
})

export default connect(mapStateToProps, {addContact: updateContact})(ContactsListScreen)