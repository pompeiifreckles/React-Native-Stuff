import React, { useState, useEffect } from 'react'
import { View, Text, TextInput } from 'react-native'
import { TouchableOpacity } from 'react-native-gesture-handler'

import { connect } from 'react-redux'
import { updateContact } from '../redux/actions'

const AddContactScreen = ({navigation, addContact}) => {
    let [contact, setContact] = useState({name: null, phone: null})

    const _handleNameChange = name => {
        setContact({...contact, name})
    }

    const _handlePhoneChange = phone => {
        setContact({...contact, phone: phone.replace(/[^0-9]/g, '')})
    }

    const _handleSubmit = () => {
        if(+contact.phone && contact.phone.length === 10 && contact.name !== null && contact.name !== '') {
            addContact({name: contact.name, phone: contact.phone})
            navigation.navigate('Contacts')
        }
    }

    useEffect(() => {
        navigation.setOptions({headerRight: () => (
            <>
                <TouchableOpacity onPress={_handleSubmit}>
                <Text style={{color: '#62a7d1', fontSize: 18, paddingRight: 20}}>Submit</Text>
                </TouchableOpacity>
            </>
         )
        })
    }, [contact])

    return(
        <View>

            <View style={{paddingLeft: 20, paddingRight: 20, paddingTop: 20}}>
            <TextInput 
                placeholder='Name'
                style={{borderColor: 'black', paddingLeft: 15, borderWidth: 1, fontSize: 20}}
                value={contact.name}
                onChangeText={_handleNameChange}
            />
            </View>

            <View style={{padding: 20}}>
            <TextInput 
                placeholder='Phone'
                style={{borderColor: 'black', paddingLeft: 15, borderWidth: 1, fontSize: 20}}
                autoCapitalize='none'
                autoCorrect={false}
                keyboardType='numeric'
                maxLength={10}
                value={contact.phone}
                onChangeText={_handlePhoneChange}
            />
            </View>

        </View>

    )
}

export default connect(null, {addContact: updateContact})(AddContactScreen)