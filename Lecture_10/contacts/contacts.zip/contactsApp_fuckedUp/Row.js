import React from 'react'
import {Text, View} from 'react-native'

const Row = ({contact}) =>(
    <View style={{flexDirection: 'row'}}>
        <Text style={{flex: 0.9, textAlign: 'left', fontSize: 18, paddingRight: 50, paddingLeft: 20}}>{contact.name}</Text>
        <Text style={{textAlign: 'left', fontSize: 18}}>{contact.phone}</Text>
    </View>
)

export default Row